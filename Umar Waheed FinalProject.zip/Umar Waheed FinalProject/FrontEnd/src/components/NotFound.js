import React from 'react'

function NotFound() {
  return (
    <div className='container'>
        <h1 className='text-center display-3'>404, Page not Found</h1>

    </div>
  )
}

export default NotFound