import React from 'react'

function About() {
  return (
    <div>
        {/* About*/}
      <section className="about-section text-center" id="about">
        <div className="container px-4 px-lg-5">
          <div className="row gx-4 gx-lg-5 justify-content-center">
            <div className="col-lg-8">
              <h2 className="text-white mb-4">Built with FitFlow</h2>
              <p className="text-white">
              With FitFlow, you can easily track and monitor your progress for five popular exercises - running, swimming, walking, hiking, and bicycle riding.
              </p>
              <p className="text-white">
              With its user-friendly interface, FitFlow makes it easy to log your daily exercise routines and see how you're progressing towards your goals. The app features detailed tracking for each of the five exercises, so you can monitor your distance, speed, and duration with ease. Whether you're looking to improve your endurance or simply want to stay active, FitFlow is the perfect tool to help you reach your fitness objectives.
              </p>
              <div>
              <div className="row gx-4 gx-lg-5">
            <div className="col-md-4 mb-3 mb-md-0">
              <div className="card py-4 h-100">
                <div className="card-body text-center">
                  <h4 className="text-uppercase m-0">Running</h4>
                  <hr className="my-4 mx-auto text-center" />
                  <div className="small text-black-50">
                    <table></table>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-4 mb-3 mb-md-0">
              <div className="card py-4 h-100">
                <div className="card-body text-center">

                  <h4 className="text-uppercase m-0">Swimming</h4>
                  <hr className="my-4 mx-auto" />
                  <div className="small text-black-50">
                    <table></table>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-4 mb-3 mb-md-0">
              <div className="card py-4 h-100">
                <div className="card-body text-center">
                  <h4 className="text-uppercase m-0">hiking</h4>
                  <hr className="my-4 mx-auto" />
                  <div className="small text-black-50">
                    <table></table>
                  </div>
                </div>
              </div>
            </div>  
          </div>
          <div className="row gx-4 gx-lg-5">
          <div className="col-md-6 mb-3 mb-md-0 mt-3">
              <div className="card py-4 h-100">
                <div className="card-body text-center">
                  <h4 className="text-uppercase m-0">Walking</h4>
                  <hr className="my-4 mx-auto" />
                  <div className="small text-black-50">
                    <table></table>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-6 mb-3 mb-md-0 mt-3">
              <div className="card py-4 h-100">
                <div className="card-body text-center">
                  <h4 className="text-uppercase m-0">Bicycle Riding</h4>
                  <hr className="my-4 mx-auto" />
                  <div className="small text-black-50"><table></table></div>
                </div>
              </div>
            </div>
          </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default About