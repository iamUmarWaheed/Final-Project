import React from 'react'
import { Link } from 'react-router-dom'

function Header() {
  return (
    <div>
        {/* Masthead*/}
      <header className="masthead">
        <div className="container px-4 px-lg-5 d-flex h-100 align-items-center justify-content-center">
          <div className="d-flex justify-content-center">
            <div className="text-center">
              <h1 className="mx-auto my-0 text-uppercase">FitFlow</h1>
              <h2 className="text-white mx-auto mt-2 mb-5">FitFlow is an innovative exercise tracker web app designed to help you achieve your fitness goals.</h2>
              <h2 className="text-white mx-auto mt-2 mb-5">Start your fitness journey today and see the results for yourself!</h2>
              <Link className="btn btn-primary" to="/tracker">Get Started</Link>
            </div>
          </div>
        </div>
      </header>
    </div>
  )
}

export default Header