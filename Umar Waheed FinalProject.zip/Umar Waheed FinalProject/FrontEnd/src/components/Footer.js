import React from 'react'
import { Link } from 'react-router-dom'

function Footer() {
  return (
    <div>
      
        {/* Footer*/}
      <footer className="footer bg-black small text-center text-white-50">
      <div className="social d-flex justify-content-center">
        <Link className="mx-2" href="#!"><i className="fab fa-twitter" /></Link>
        <Link className="mx-2" href="#!"><i className="fab fa-facebook-f" /></Link>
        <Link className="mx-2" href="#!"><i className="fab fa-github" /></Link>
      </div>
        <div className="container px-4 px-lg-5">Copyright © FitFlow Website 2023</div>
        
        </footer>
    </div>
  )
}

export default Footer