import React, { useEffect, useState } from 'react'

function Tracker(props) {
  // making an object for emptying the input fields after put one user
  const initialValues = {
    id : null,
    name : '',
    description: '',
    exersice: '',
    date: '',
    duration: ''
  }

  // defining the hook for getting the input fields data
  const [datas, setDatas] = useState(initialValues);

  const [editId, setEditId] = useState("");
  const [btnState, setBtnState] = useState(true);

  //make a arrewo function for getting the input fields values
  const handleInput = (event) => {
    const {name, value} = event.target;
    setDatas ({...datas, [name]:value})
    console.log(datas);
  }
  const onSubmit=async()=>{
    
    await fetch("http://localhost:4000/post",{
      method:"POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify(datas),
    });
    
    showData();
    setDatas(initialValues);
  }
  
  const [datas1,setDatas1]=useState([]);
  const showData = async()=>{
    const data1= await fetch("http://localhost:4000/read");
    let tableData = await data1.json();
    setDatas1(tableData)
    console.log("fdgfdgfdhgfhg",datas1);
    }

    const deleteData = async(id) =>{
      await fetch(`http://localhost:4000/del/${id}`,{
        method:"Delete"
      })
      showData()
    }

    useEffect(()=>{
      showData()
    },[])

    //edit ka function
  const editData = async (abc) => {
    const krdoEdit = await fetch(`http://localhost:4000/edit/${abc}`);
    let jsonwla = await krdoEdit.json();
    setDatas(jsonwla);
    setEditId(abc);
    setBtnState(false);
    console.log("eddd", jsonwla);
    alert("Go to the Form to Edit");
  };

  //update ka function
  const updateData = async () => {
    //e bs aik variable hy jo k call hony pe parameter ata h vgra vgra
    // e.preventDefault();  //e.preventdefault page reload hony se rokta hy
    await fetch(`http://localhost:4000/update/${editId}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(datas), //transfers data in string. input save krwana h
    }); //post backend wala
    setBtnState(true);
    showData();
    
  };
  return (
    <div>
        {/*Form*/}
      <section className="projects-section bg-dark" id="projects">
        <div className="container px-4 px-lg-5 col-8">
        <div className='track-main'>
    <h1 className='text-center text-white display-3' >Tracker</h1>
    <br/>
    <h3 className='text-center text-white display-3'>Enter Your Data</h3>
    </div>
          <div className="row gx-0 mb-4 mb-lg-5 align-items-center text-white">
          <form onSubmit={(event) => {
            event.preventDefault();
            
            setDatas(initialValues);
          }}>
        <div className="mb-3">
          <label htmlFor="exampleInputName" className="form-label">Name</label>
          <input type="text" value={datas.name} onChange={handleInput} name='name' className="form-control" id="exampleInputName" />
        </div>
  
        <div className="mb-3">
          <label htmlFor="exampleInputDescription" className="form-label">Description</label>
          <input type="text" value={datas.description} onChange={handleInput} name='description' className="form-control" id="exampleInputDescription" />
        </div>

        <div className='mb-3'>
        <label>Select Exercise</label>
        <select class="form-select" value={datas.exersice} name='exersice' onChange={handleInput} aria-label="Default select example">
        <option selected>Open this select menu</option>
        <option value="Running">Running</option>
        <option value="Cycling">Cycling</option>
        <option value="Swimming">Swimming</option>
        <option value="Walking">Walking</option>
        <option value="Hiking">Hiking</option>
        </select>
        </div>

        <div className='mb-3'>
        <label htmlFor="dates1" className='form-label'>Select Date</label>
        <input type="date" value={datas.date} onChange={handleInput} name="date" id="dates1" data-provide="datepicker"  className='form-control'/>
        </div>

        <div className='mb-3'>
        <label htmlFor="dura1" className='form-label'>Duration (in minutes)</label>
        <input type="text" value={datas.duration} onChange={handleInput} name="duration" id="dura1" className='form-control' />
        </div>
          <div className='text-center text-white'>
          {btnState ? (
                  <button
                    type="submit"
                    className="btn btn-outline-primary"
                    onClick={onSubmit}
                  >
                   <a className='text-white text-decoration-none'  href='#table'> Save Data</a>
                  </button>
                ) : (
                  <button
                    type="submit"
                    className="btn btn-primary"
                    onClick={updateData}
                  >
                    <a className='text-white text-decoration-none'  href='#table'> Update Data</a>
                  </button>
                )}
        </div>
      </form>
          </div>
          
        </div>
      </section>
      <div>
        
      {/* Table*/}
      <section className="contact-section bg-black" id='table'>
        <div className="container px-4 px-lg-5">
          <div>
          <h1 className='text-center text-white display-3 '>All Users Data</h1>
          <table className='table table-bordered text-center text-white  '>
            <tr>
              {/* <th>ID</th>    */}
              <th>Name</th>
              <th>Description</th>
              <th>Exercise</th>
              <th>Date</th>
              <th>Duration</th>
              <th>Actions</th>
            </tr>
            {
              
                // here we use props and map(as a for loop) to get data from api
                datas1.map((user)=>(
                <tr>
                  
                  <td>{user.name}</td>
                  <td>{user.description}</td>
                  <td>{user.exersice}</td>
                  <td>{user.date}</td>
                  <td>{user.duration}</td>
                  <td><button className='btn btn-outline-primary' onClick={()=>editData(user._id)}>Edit</button></td>
                  
                  <td><button className='btn btn-outline-danger' onClick={()=>deleteData(user._id)}>Delete</button></td>
                </tr>
              ))
              
            }
          </table>
          </div>
          <div className='text-center'>
          <a className="btn btn-outline-primary" href="#projects">Add More</a>
          </div>   
        </div>
      </section>
    </div>
    </div>
  )
}

export default Tracker