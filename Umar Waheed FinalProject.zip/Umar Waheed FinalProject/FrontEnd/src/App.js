import React, { useState } from 'react'
import "./App.css"
import About from './components/About'
import Footer from './components/Footer'
import Header from './components/Header'
import Navbar from './components/Navbar'
import Tracker from './components/Tracker'
import NotFound from './components/NotFound'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'




function App() {
  
  // defining the hook for getting the data form Api
  const [data, setData] = useState([]);
  
  // function for deleting data here deleteData is name of function 
  // jitna bhi kaam edit or delete hota ha wo id k zariaye hota ha
  const deleteData = (id) => {
            setData(data.filter((newdata) => newdata.id !== id));
  }

  // function for adding the new user(data) with id increment
  const addData = async () => {
        const data= await fetch("http://localhost:4000/read");
        const tableData = await data.json();
        setData(tableData)
        console.log("finalData",tableData);


  }
  return (
    <div>
      <Router>
      <Navbar/>
      <Routes>
      <Route exact path="/" element={<Header/>}/>
      <Route path="/about" element={<About/>}/>
      <Route path="/tracker" element={<Tracker adddata = {addData}/>}/>
      <Route path='*' element={<NotFound/>}/>
      </Routes>
      <Footer/>
      </Router>
      
    </div>
  )
}

export default App