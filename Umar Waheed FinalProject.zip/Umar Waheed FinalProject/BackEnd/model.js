const mongoose = require ('mongoose')
const userInfo = mongoose.Schema({
    name : String,
    description : String,
    exersice : String,
    date : String,
    duration : Number
})
module.exports = mongoose.model ('exercisetracker', userInfo);